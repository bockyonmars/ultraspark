import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { BookingRequestStatus, CustomerActivityType } from '@prisma/client';
import {
  assertRequiredFields,
  combineDetails,
  getNumberValue,
  getStringValue,
  PayloadRecord,
  splitFullName,
} from '../../common/utils/public-form-payload.util';
import { AnalyticsService } from '../analytics/analytics.service';
import { AuditLogsService } from '../audit-logs/audit-logs.service';
import { CustomerActivitiesService } from '../customer-activities/customer-activities.service';
import { CustomersService } from '../customers/customers.service';
import { EmailService } from '../email/email.service';
import { PrismaService } from '../prisma.service';
import { ServicesService } from '../services/services.service';
import { CreateBookingRequestDto } from './dto/create-booking-request.dto';
import { UpdateBookingRequestStatusDto } from './dto/update-booking-request-status.dto';

@Injectable()
export class BookingRequestsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly customersService: CustomersService,
    private readonly servicesService: ServicesService,
    private readonly emailService: EmailService,
    private readonly customerActivitiesService: CustomerActivitiesService,
    private readonly analyticsService: AnalyticsService,
    private readonly auditLogsService: AuditLogsService,
  ) {}

  async createPublic(payload: PayloadRecord) {
    const fullName = getStringValue(payload, ['fullName', 'Full Name']);
    const nameParts = splitFullName(fullName);
    const email = getStringValue(payload, ['email', 'Email', 'Email Address']);
    const phone = getStringValue(payload, ['phone', 'Phone Number']);
    const serviceType = getStringValue(payload, [
      'serviceType',
      'Service Type',
    ]);
    const date = getStringValue(payload, ['preferredDate', 'date', 'Date']);
    const time = getStringValue(payload, ['preferredTime', 'time', 'Time']);
    const address = getStringValue(payload, ['address', 'Address']);
    const additionalNotes = getStringValue(payload, [
      'additionalNotes',
      'Additional Notes',
    ]);

    assertRequiredFields(
      [
        { label: 'fullName', value: fullName },
        {
          label: 'serviceType',
          value: serviceType ?? getStringValue(payload, ['serviceId']),
        },
        { label: 'date', value: date },
        { label: 'time', value: time },
        { label: 'address', value: address },
      ],
      'Booking submission is missing required fields',
    );

    if (!email && !phone) {
      throw new BadRequestException(
        'Booking submission requires an email or phone number',
      );
    }

    return this.create({
      firstName:
        getStringValue(payload, ['firstName']) ?? nameParts.firstName ?? 'N/A',
      lastName:
        getStringValue(payload, ['lastName']) ?? nameParts.lastName ?? 'N/A',
      email,
      phone,
      serviceId: getStringValue(payload, ['serviceId']),
      serviceType,
      address,
      postcode: getStringValue(payload, ['postcode', 'Postcode']),
      propertyType: getStringValue(payload, ['propertyType', 'Property Type']),
      bedrooms: getNumberValue(payload, ['bedrooms', 'Bedrooms']),
      bathrooms: getNumberValue(payload, ['bathrooms', 'Bathrooms']),
      preferredDate: date,
      preferredTime: time,
      details: combineDetails([
        additionalNotes ? `Additional notes: ${additionalNotes}` : undefined,
        getStringValue(payload, ['details']),
      ]),
    });
  }

  async create(createDto: CreateBookingRequestDto & { serviceType?: string }) {
    assertRequiredFields(
      [
        { label: 'firstName', value: createDto.firstName },
        { label: 'lastName', value: createDto.lastName ?? 'N/A' },
        { label: 'preferredDate', value: createDto.preferredDate },
        { label: 'preferredTime', value: createDto.preferredTime },
        { label: 'address', value: createDto.address },
      ],
      'Booking submission is missing required fields',
    );

    if (!createDto.email && !createDto.phone) {
      throw new BadRequestException('Email or phone is required');
    }

    if (!createDto.serviceId && !createDto.serviceType) {
      throw new BadRequestException(
        'Booking submission requires serviceType or serviceId',
      );
    }

    let service = createDto.serviceId
      ? await this.servicesService.findById(createDto.serviceId)
      : undefined;

    if (!service && createDto.serviceType) {
      service = await this.servicesService.findByReference(
        createDto.serviceType,
      );
    }

    if (!service) {
      throw new NotFoundException(
        'No service matched the provided serviceType/serviceId',
      );
    }

    const customer = await this.customersService.createOrMatch({
      firstName: createDto.firstName,
      lastName: createDto.lastName,
      email: createDto.email,
      phone: createDto.phone,
    });

    const bookingRequest = await this.prisma.bookingRequest.create({
      data: {
        customerId: customer.id,
        serviceId: service.id,
        address: createDto.address,
        postcode: createDto.postcode,
        propertyType: createDto.propertyType,
        bedrooms: createDto.bedrooms,
        bathrooms: createDto.bathrooms,
        preferredDate: createDto.preferredDate
          ? new Date(createDto.preferredDate)
          : undefined,
        preferredTime: createDto.preferredTime,
        details: createDto.details,
      },
      include: {
        customer: true,
        service: true,
      },
    });

    await Promise.allSettled([
      this.emailService.sendAdminBookingAlert({
        customerName:
          `${customer.firstName ?? ''} ${customer.lastName ?? ''}`.trim() ||
          'Customer',
        customerEmail: customer.email,
        customerPhone: customer.phone,
        serviceName: service.name,
        preferredDate: createDto.preferredDate,
        preferredTime: createDto.preferredTime,
        bookingRequestId: bookingRequest.id,
      }),
      ...(customer.email
        ? [
            this.emailService.sendCustomerBookingConfirmation({
              recipient: customer.email,
              customerName: customer.firstName ?? 'there',
              customerPhone: customer.phone,
              serviceName: service.name,
              requestedDate: createDto.preferredDate,
              requestedTime: createDto.preferredTime,
              location: createDto.address,
              bookingRequestId: bookingRequest.id,
            }),
          ]
        : []),
      this.analyticsService.trackEvent({
        type: 'BOOKING_SUBMITTED',
        entityType: 'BookingRequest',
        entityId: bookingRequest.id,
        metadata: {
          customerId: customer.id,
          serviceId: service.id,
        },
      }),
      this.auditLogsService.create({
        action: 'BOOKING_CREATED',
        entityType: 'BookingRequest',
        entityId: bookingRequest.id,
        description: 'Public booking request submitted',
        metadata: {
          customerId: customer.id,
          serviceId: service.id,
        },
      }),
    ]);

    return bookingRequest;
  }

  findAll() {
    return this.prisma.bookingRequest.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        customer: true,
        service: true,
      },
    });
  }

  async findOne(id: string) {
    const bookingRequest = await this.prisma.bookingRequest.findUnique({
      where: { id },
      include: {
        customer: true,
        service: true,
        emailLogs: true,
      },
    });

    if (!bookingRequest) {
      throw new NotFoundException('Booking request not found');
    }

    return bookingRequest;
  }

  async updateStatus(
    id: string,
    updateDto: UpdateBookingRequestStatusDto,
    adminUserId?: string,
  ) {
    const existing = await this.prisma.bookingRequest.findUnique({
      where: { id },
    });

    if (!existing) {
      throw new NotFoundException('Booking request not found');
    }

    const bookingRequest = await this.prisma.bookingRequest.update({
      where: { id },
      data: {
        status: updateDto.status as BookingRequestStatus,
      },
      include: {
        customer: true,
        service: true,
      },
    });

    await Promise.allSettled([
      this.customerActivitiesService.create({
        customerId: bookingRequest.customerId,
        type: CustomerActivityType.BOOKING_UPDATED,
        title: `Booking status updated to ${updateDto.status}`,
        description: bookingRequest.service?.name,
        relatedEntityType: 'BookingRequest',
        relatedEntityId: id,
        createdById: adminUserId,
      }),
      this.auditLogsService.create({
        action: 'BOOKING_STATUS_UPDATED',
        entityType: 'BookingRequest',
        entityId: id,
        description: `Booking request status updated to ${updateDto.status}`,
        adminUserId,
        metadata: {
          status: updateDto.status,
        },
      }),
    ]);

    return bookingRequest;
  }
}
